document.addEventListener('DOMContentLoaded', function () {
  fetch(`${ajaxObject.ajax_url}?action=get_nakshatra`)
    .then(response => {
      if (!response.ok) {
        throw new Error("Network response was not ok");
      }
      return response.json();
    })
    .then(data => {
      const dropdown = document.getElementById('nakshatra');
      if (data.success && dropdown) {
        data.data.forEach(item => {
          const option = document.createElement('option');
          option.value = item.name;
          option.textContent = item.name;
          dropdown.appendChild(option);
        });
      }
    })
    .catch(error => {
      console.error("Error loading Nakshatra JSON:", error);
    });
});
